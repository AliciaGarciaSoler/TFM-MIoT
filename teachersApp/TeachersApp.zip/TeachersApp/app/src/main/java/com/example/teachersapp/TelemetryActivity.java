package com.example.teachersapp;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;


import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class TelemetryActivity extends AppCompatActivity {


    private Spinner spinner;

    private MqttAndroidClient mqttClient;

    // AtomicInteger is used to ensure thread-safe access to the values
    private AtomicInteger co2Value = new AtomicInteger();
    private AtomicInteger tempValue = new AtomicInteger();
    private AtomicInteger humValue = new AtomicInteger();
    private AtomicInteger timestampValue = new AtomicInteger();

    private List<Entry> co2Entries = new ArrayList<>();
    private List<Entry> tempEntries = new ArrayList<>();
    private List<Entry> humEntries = new ArrayList<>();

    private LineDataSet co2DataSet;
    private LineDataSet tempDataSet;
    private LineDataSet humDataSet;

    private LineChart co2Chart;
    private LineChart tempChart;
    private LineChart humChart;

    private static final String CHANNEL_ID = "notification_channel2";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_telemetry);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom_telemetry, null);

        // Set the custom action bar
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);

        co2Value.set((int) 800);
        tempValue.set((int) 20);
        humValue.set((int) 50);
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        long currentTimeMillis = hour * 3600000 + minute * 60000 + second * 1000;
        timestampValue.set((int) currentTimeMillis);

        mqttClient = MQTTClientManager.getMqttClient(getApplicationContext());
        String topic = "estudio3/classroomA/data/SCD30";
        int qos = 0; // Quality of Service level
        try {
            IMqttToken token = mqttClient.subscribe(topic, qos);
            token.setActionCallback(new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    mqttClient.setCallback(new MqttCallback() {
                        @Override
                        public void connectionLost(Throwable cause) {

                        }
                        // Studies the recieved message and call on a function to update the charts
                        @Override
                        public void messageArrived(String topic, MqttMessage message) throws Exception {
                            if (topic.equals("estudio3/classroomA/data/SCD30")) {
                                String payload = new String(message.getPayload());
                                String[] values = payload.split("/");
                                co2Value.set((int) Float.parseFloat(values[0]));
                                tempValue.set((int) Float.parseFloat(values[1]));
                                humValue.set((int) Float.parseFloat(values[2]));
                                Calendar calendar = Calendar.getInstance();
                                int hour = calendar.get(Calendar.HOUR_OF_DAY);
                                int minute = calendar.get(Calendar.MINUTE);
                                int second = calendar.get(Calendar.SECOND);
                                long currentTimeMillis = hour * 3600000 + minute * 60000 + second * 1000;
                                timestampValue.set((int) currentTimeMillis);
                                updateCharts();
                            }
                            else{
                                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                // Get the current time
                                String time = sdf.format(new Date());
                                String alarm;
                                String emoji = "";
                                switch (topic){
                                    case "estudio3/classroomA/alert/noise":
                                        emoji = "🔊"; // Speaker emoji for noise detection

                                        alarm =  emoji + " " + emoji + " " + getString(R.string.noise) + emoji + " " + emoji;
                                        // Create the notification
                                        createNotification(time, alarm);

                                        break;
                                    case "estudio3/classroomA/alert/touch":
                                        emoji = "👆"; // Finger pointing emoji for touch detection
                                        alarm =  emoji + " " + emoji + " " + getString(R.string.touch) + emoji + " " + emoji;
                                        createNotification(time, alarm);

                                        break;
                                    case "estudio3/classroomA/alert/pir":
                                        emoji = "🚶"; // Pedestrian emoji for presence detection
                                        alarm =  emoji + " " + emoji + " " + getString(R.string.pir) + emoji + " " + emoji;
                                        createNotification(time, alarm);

                                        break;
                                    case "estudio3/classroomA/alert/flame":
                                        emoji = "🔥"; // Fire emoji for fire detection
                                        alarm =  emoji + " " + emoji + " " + getString(R.string.flame) + emoji + " " + emoji;
                                        createNotification(time, alarm);

                                        break;
                                    default:
                                        alarm =  "alarm";
                                        time = "now";
                                        createNotification(time, alarm);
                                        break;
                                }
                            }
                        }

                        @Override
                        public void deliveryComplete(IMqttDeliveryToken token) {
                        }
                    });
                }


                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    exception.printStackTrace();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }

        // Get UI elements
        tempChart = findViewById(R.id.chartTemperature);
        humChart = findViewById(R.id.chartHumidity);
        co2Chart = findViewById(R.id.chartCO2);
        spinner = findViewById(R.id.spinner_plots);

        // Adjust chart padding
        tempChart.setViewPortOffsets(80f, 0f, 50f, 200f);
        humChart.setViewPortOffsets(80f, 0f, 50f, 200f);
        co2Chart.setViewPortOffsets(100f, 0f, 50f, 200f);


        tempChart.setExtraOffsets(10f, 10f, 20f, 20f);
        humChart.setExtraOffsets(10f, 10f, 20f, 20f);
        co2Chart.setExtraOffsets(10f, 10f, 20f, 20f);


        // Set pop up info window
        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an AlertDialog.Builder
                AlertDialog.Builder builder = new AlertDialog.Builder(TelemetryActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml((getString(R.string.infoAlert))));

                // Add a button
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });

                // Create the AlertDialog and show it
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        spinner = findViewById(R.id.spinner_plots);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.plot_options, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedPlot = spinner.getSelectedItem().toString();

                // Show the selected plot
                switch (selectedPlot) {
                    case "Temperature":
                    case "Temperatura":
                        tempChart.setVisibility(View.VISIBLE);
                        humChart.setVisibility(View.INVISIBLE);
                        co2Chart.setVisibility(View.INVISIBLE);
                        break;
                    case "Humidity":
                    case "Humedad":
                        tempChart.setVisibility(View.INVISIBLE);
                        humChart.setVisibility(View.VISIBLE);
                        co2Chart.setVisibility(View.INVISIBLE);
                        break;
                    case "CO2":
                        tempChart.setVisibility(View.INVISIBLE);
                        humChart.setVisibility(View.INVISIBLE);
                        co2Chart.setVisibility(View.VISIBLE);
                        break;
                }


                updateCharts();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

    }

    private void updateCharts() {
        // Add new data point to CO2 chart
        co2Entries.add(new Entry(timestampValue.get(), co2Value.get()));
        if (co2DataSet == null) {
            co2DataSet = new LineDataSet(co2Entries, "CO2 (ppm)");
            co2DataSet.setColors(ColorTemplate.MATERIAL_COLORS);
            co2DataSet.setValueTextColor(android.R.color.black);
            co2DataSet.setLineWidth(2f);
            co2DataSet.setDrawValues(false);
            co2DataSet.setDrawCircles(true);
            co2DataSet.setCircleRadius(5f);
            co2DataSet.setCircleColor(Color.RED);
            co2Chart.getLegend().setEnabled(false);
            co2Chart.getDescription().setEnabled(false);
            co2Chart.setNoDataText("No data available.");
            XAxis co2XAxis = co2Chart.getXAxis();
            co2XAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            co2XAxis.setValueFormatter(new MyValueFormatter("dd/MM/yyyy HH:mm:ss"));
            co2XAxis.setLabelRotationAngle(45f);
            YAxis co2YAxis = co2Chart.getAxisLeft();
            co2YAxis.setDrawGridLines(true);
            co2YAxis.setTextColor(ContextCompat.getColor(this, android.R.color.black)); // Modify this line
            co2YAxis.setGranularity(1f);
            co2YAxis.setDrawLabels(true);
            co2YAxis.setValueFormatter(new FloatValueFormatter());
            co2Chart.getAxisRight().setEnabled(false);
        } else {
            co2DataSet.notifyDataSetChanged();
        }
        LineData co2LineData = new LineData(co2DataSet);
        co2Chart.setData(co2LineData);
        co2Chart.invalidate();

        // Add new data point to temperature chart
        tempEntries.add(new Entry(timestampValue.get(), tempValue.get()));
        if (tempDataSet == null) {
            tempDataSet = new LineDataSet(tempEntries, "Temperature (°C)");
            tempDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
            tempDataSet.setValueTextColor(android.R.color.black);
            tempDataSet.setLineWidth(2f);
            tempDataSet.setDrawValues(false);
            tempDataSet.setDrawCircles(true);
            tempDataSet.setCircleRadius(5f);
            tempDataSet.setCircleColor(Color.RED);
            tempChart.getLegend().setEnabled(false);
            tempChart.getDescription().setEnabled(false);
            tempChart.setNoDataText("No data available.");
            XAxis tempXAxis = tempChart.getXAxis();
            tempXAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            tempXAxis.setValueFormatter(new MyValueFormatter("dd/MM/yyyy HH:mm:ss"));
            tempXAxis.setLabelRotationAngle(45f);
            YAxis tempYAxis = tempChart.getAxisLeft();
            tempYAxis.setDrawGridLines(true);
            tempYAxis.setTextColor(ContextCompat.getColor(this, android.R.color.black));
            tempYAxis.setGranularity(1f);
            tempYAxis.setDrawLabels(true);
            tempYAxis.setValueFormatter(new FloatValueFormatter());
            tempChart.getAxisRight().setEnabled(false);
        } else {
            tempDataSet.notifyDataSetChanged();
        }
        LineData tempLineData = new LineData(tempDataSet);
        tempChart.setData(tempLineData);
        tempChart.invalidate(); // Show the graph

        // Add new data point to humidity chart
        humEntries.add(new Entry(timestampValue.get(), humValue.get()));
        if (humDataSet == null) {
            humDataSet = new LineDataSet(humEntries, "Humidity (%)");
            humDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
            humDataSet.setValueTextColor(android.R.color.black);
            humDataSet.setLineWidth(2f);
            humDataSet.setDrawValues(false);
            humDataSet.setDrawCircles(true);
            humDataSet.setCircleRadius(5f);
            humDataSet.setCircleColor(Color.RED);

            humChart.getLegend().setEnabled(false);
            humChart.getDescription().setEnabled(false);
            humChart.setNoDataText("No data available.");
            XAxis humXAxis = humChart.getXAxis();
            humXAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            humXAxis.setValueFormatter(new MyValueFormatter("dd/MM/yyyy HH:mm:ss"));
            humXAxis.setLabelRotationAngle(45f);

            YAxis humYAxis = humChart.getAxisLeft();
            humYAxis.setDrawGridLines(true);
            humYAxis.setTextColor(ContextCompat.getColor(this, android.R.color.black));
            humYAxis.setGranularity(1f);
            humYAxis.setDrawLabels(true);
            humYAxis.setValueFormatter(new FloatValueFormatter());
            humChart.getAxisRight().setEnabled(false);
        } else {
            humDataSet.notifyDataSetChanged();
        }
        LineData humLineData = new LineData(humDataSet);
        humChart.setData(humLineData);
        humChart.invalidate();
    }
    private void createNotification(String time, String alert) {

        // Create a unique notification ID based on current time
        int notificationId = (int) System.currentTimeMillis();
        createNotificationChannel();

        String contentText;
        contentText = alert +" "+ getString(R.string.at)+" " + time;
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.warning)
                .setColor(Color.RED)
                .setContentTitle(getString(R.string.WARNING))
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification Channel";
            String description = "Channel for alerts";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}
