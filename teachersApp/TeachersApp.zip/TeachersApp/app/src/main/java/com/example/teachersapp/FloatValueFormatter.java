package com.example.teachersapp;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.ValueFormatter;
import java.text.NumberFormat;
import java.util.Locale;

// Returns the string of the float, to the show on the y axis of the telemetry
public class FloatValueFormatter extends ValueFormatter {
    @Override
    public String getAxisLabel(float value, AxisBase axis) {
        return String.valueOf(value);
    }
}