package com.example.teachersapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class AppSettingsActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private EditText ipEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set Layout and action bar
        setContentView(R.layout.app_settings);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom_settings, null);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);

        // Initialize UI elements
        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        ipEditText = findViewById(R.id.ipEditText);
        saveButton = findViewById(R.id.saveButton);

        CheckBox showPasswordCheckBox = findViewById(R.id.showPasswordCheckBox);
        // Set the Visibility of the password depending on the selected option
        showPasswordCheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    passwordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                } else {
                    passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                }
            }
        });

        // Get saved settings
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(this);
        String savedUsername = preferences.getString("mqtt_username", "appuser");
        String savedPassword = preferences.getString("mqtt_password", "3stud10e0e");
        String savedip = preferences.getString("mqtt_ip", "tcp://192.168.0.9:1883");

        // Set the saved settings in EditText fields
        usernameEditText.setText(savedUsername);
        passwordEditText.setText(savedPassword);
        ipEditText.setText(savedip);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the new settings from EditText fields
                String newUsername = usernameEditText.getText().toString();
                String newPassword = passwordEditText.getText().toString();
                String newip = ipEditText.getText().toString();

                // Save the new settings
                SharedPreferences.Editor editor = preferences.edit();
                editor.putString("mqtt_username", newUsername);
                editor.putString("mqtt_password", newPassword);
                editor.putString("mqtt_ip", newip);
                editor.apply();
                // Set result indicating that the settings were modified
                setResult(RESULT_OK);


                Toast.makeText(AppSettingsActivity.this, "Settings saved", Toast.LENGTH_SHORT).show();
                finish(); // Finish the activity
            }
        });
        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        // Set an OnClickListener to the info button
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an AlertDialog.Builder
                AlertDialog.Builder builder = new AlertDialog.Builder(AppSettingsActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml(getString(R.string.infoSettings)));

                // Add a button
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });

                // Create the AlertDialog and show it
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
}
