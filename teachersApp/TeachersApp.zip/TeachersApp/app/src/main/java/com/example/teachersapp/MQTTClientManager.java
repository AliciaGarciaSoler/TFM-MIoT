package com.example.teachersapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.widget.Toast;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

public class MQTTClientManager {
    private static MqttAndroidClient mqttAndroidClient;
    private static boolean isRestarting = false;

    // Generates client so each activity can use the same connection
    public static MqttAndroidClient getMqttClient(Context context) {
        if (mqttAndroidClient == null || isRestarting == true) {
            isRestarting = false;
            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(context.getApplicationContext());
            String brokerUrl = preferences.getString("mqtt_ip", "tcp://192.168.0.9:1883");
            String username = preferences.getString("mqtt_username", "appuser");
            String password = preferences.getString("mqtt_password", "3stud10e0e");
            String clientId = MqttClient.generateClientId();
            mqttAndroidClient = new MqttAndroidClient(context.getApplicationContext(), brokerUrl, clientId);

            // Set the connection options
            MqttConnectOptions options = new MqttConnectOptions();
            options.setUserName(username);
            options.setPassword(password.toCharArray());

            // Set a callback for connection lost and message arrival events
            mqttAndroidClient.setCallback(new MqttCallbackExtended() {
                @Override
                public void connectComplete(boolean reconnect, String serverURI) {
                    // Connection success
                }

                @Override
                public void connectionLost(Throwable cause) {
                    // Connection lost
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    // Message arrived
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                    // Delivery complete
                }
            });

            try {
                mqttAndroidClient.connect(options, null, new IMqttActionListener() {
                    @Override
                    public void onSuccess(IMqttToken asyncActionToken) {
                        // Connection success
                        subscribeToTopic(mqttAndroidClient, "estudio3/classroomA/alert/#", 1, context);
                    }

                    @Override
                    public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                        // Connection failure
                        exception.printStackTrace();
                    }
                });
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
        return mqttAndroidClient;
    }

    private static void subscribeToTopic(MqttAndroidClient client, String topic, int qos, Context context) {
        try {
            client.subscribe(topic, qos, null, new IMqttActionListener() {
                @Override
                public void onSuccess(IMqttToken asyncActionToken) {
                    // Subscription success
                    Toast.makeText(context.getApplicationContext(), "Subscribed", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onFailure(IMqttToken asyncActionToken, Throwable exception) {
                    // Subscription failure
                    Toast.makeText(context.getApplicationContext(), "Failed", Toast.LENGTH_SHORT).show();

                    exception.printStackTrace();
                }
            });
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
    public static void setRestartingFlag(boolean value) {
        isRestarting = value;
    }
}
