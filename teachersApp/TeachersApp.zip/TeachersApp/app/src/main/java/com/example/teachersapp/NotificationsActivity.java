package com.example.teachersapp;

import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.Calendar;

public class NotificationsActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private static final String CHANNEL_ID = "notification_channel";
    private static final String MQTT_TOPIC = "estudio3/classroomA/updates/notification";

    private Spinner activitySpinner;
    private TimePicker timePicker;
    private EditText otherEditText;
    private CheckBox privateCheckBox;
    private Button okButton;
    private MqttAndroidClient mqttClient;

    private int selectedHour;
    private int selectedMinute;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);
        // Set action bar
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom_notifications, null);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);

        mqttClient = MQTTClientManager.getMqttClient(getApplicationContext());

        // Create pop up window for activity information
        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(NotificationsActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml(getString(R.string.infoNotification) ));
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        // Initialize UI elements
        activitySpinner = findViewById(R.id.activitySpinner);
        timePicker = findViewById(R.id.timePicker);
        otherEditText = findViewById(R.id.otherEditText);
        privateCheckBox = findViewById(R.id.privateCheckBox);
        okButton = findViewById(R.id.okButton);

        // Set up spinners
        ArrayAdapter<CharSequence> activityAdapter = ArrayAdapter.createFromResource(this,
                R.array.activities_array, android.R.layout.simple_spinner_item);
        activityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        activitySpinner.setAdapter(activityAdapter);
        activitySpinner.setOnItemSelectedListener(this);

        // Set up the time picker
        timePicker.setIs24HourView(true);

        // When the OK button is pressed the private checkbox is look at. If selected the app
        // only creates a notification. Else it also send the notification to the dashboard
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectedHour = timePicker.getCurrentHour();
                selectedMinute = timePicker.getCurrentMinute();
                createNotification();
                if (!privateCheckBox.isChecked()) {
                    sendMessage();
                }
            }
        });
    }
    // If "other" is selected make text input visible
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String selectedActivity = parent.getItemAtPosition(position).toString();
        if (selectedActivity.equals("Other") || selectedActivity.equals("Otro")) {
            otherEditText.setVisibility(View.VISIBLE);
        } else {
            otherEditText.setVisibility(View.GONE);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        // Do nothing
    }

    private void createNotification() {
        String selectedActivity = activitySpinner.getSelectedItem().toString();
        selectedHour = timePicker.getCurrentHour();
        selectedMinute = timePicker.getCurrentMinute();

        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, selectedHour);
        calendar.set(Calendar.MINUTE, selectedMinute);

        int notificationId = (int) System.currentTimeMillis();

        createNotificationChannel();

        String contentText;
        if (selectedActivity.equals("Other") || selectedActivity.equals("Otro") ) {
            String otherText = otherEditText.getText().toString();
            contentText = getString(R.string.remmember) + " " + otherText + " " + getString(R.string.at) + " " + String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute)+" ";
        } else {
            contentText = getString(R.string.remmember) + " " + selectedActivity + " " + getString(R.string.at) + " " + String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute)+" ";
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.notification)
                .setContentTitle(getString(R.string.ActivityReminder))
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setWhen(calendar.getTimeInMillis());

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification Channel";
            String description = "Channel for activity reminders";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    // Sets the message to be sent deppending on it it should be from the spinner of the input text
    private void sendMessage() {
        String message;
        if (activitySpinner.getSelectedItem().toString().equals("Other") || activitySpinner.getSelectedItem().toString().equals("Otro")) {
            message = otherEditText.getText().toString();
            selectedHour = timePicker.getCurrentHour();
            selectedMinute = timePicker.getCurrentMinute();
            message = message + "/" + String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute);
        } else {
            message = activitySpinner.getSelectedItem().toString();
            selectedHour = timePicker.getCurrentHour();
            selectedMinute = timePicker.getCurrentMinute();
            message = message + "/" + String.format("%02d", selectedHour) + ":" + String.format("%02d", selectedMinute);
        }

        try {
            MqttMessage mqttMessage = new MqttMessage(message.getBytes());
            mqttMessage.setQos(1);
            mqttClient.publish(MQTT_TOPIC, mqttMessage);
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }
}
