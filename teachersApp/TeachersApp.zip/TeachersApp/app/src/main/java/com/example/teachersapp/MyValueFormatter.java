package com.example.teachersapp;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.Date;

// Takes in milliseconds and transforms them into HH:mm:ss to be displayed in the x axis of the graphs
public class MyValueFormatter extends ValueFormatter {
    private final SimpleDateFormat dateFormat;

    public MyValueFormatter(String pattern) {
        dateFormat = new SimpleDateFormat(pattern);
    }

    @Override
    public String getAxisLabel(float value, AxisBase axis) {
        long millis = (long) value;
        Date date = new Date(millis);

        // Modify the date format pattern to "HH:mm:ss"
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm:ss");
        String formattedTime = timeFormat.format(date);

        return formattedTime;
    }
}