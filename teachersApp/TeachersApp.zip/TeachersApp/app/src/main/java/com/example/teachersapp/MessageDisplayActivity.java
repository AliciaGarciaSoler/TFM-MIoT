package com.example.teachersapp;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.text.Html;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttMessageListener;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttSecurityException;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MessageDisplayActivity extends AppCompatActivity {

    TextView messageTextView;
    private static final String CHANNEL_ID = "notification_channel1";
    private MqttAndroidClient mqttClient;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Set Layout and action bar
        setContentView(R.layout.activity_message_display);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom_alerts, null);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);
        // Get MQTT client
        mqttClient = MQTTClientManager.getMqttClient(getApplicationContext());

        messageTextView = findViewById(R.id.text_view_messages);

        Button deleteButton = findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onDeleteButtonClick(v);
            }
        });
        // Create info pop up window
        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MessageDisplayActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml(getString(R.string.infoAlert)));
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        mqttClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
           public void messageArrived(String topic, MqttMessage message)
           {
               SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
               String time = sdf.format(new Date());


               String alarm;
               String newText;
               String emoji = "";
                // Set notification and text according to the alarm received
               String existingText = messageTextView.getText().toString();
               switch (topic){
                   case "estudio3/classroomA/alert/noise":
                       emoji = "🔊"; // Speaker emoji for noise detection
                       alarm =  emoji + " " + emoji + " " + getString(R.string.noise) + emoji + " " + emoji;
                       newText = alarm + " " + getString(R.string.at) +" "+ time;
                       createNotification(time, alarm);
                       messageTextView.setText(newText + "\n" + existingText);

                       break;
                   case "estudio3/classroomA/alert/touch":
                       emoji = "👆"; // Finger pointing up emoji for touch detection
                       alarm =  emoji + " " + emoji + " " + getString(R.string.touch) + emoji + " " + emoji;
                       newText = alarm + " " + getString(R.string.at) +" "+ time;
                       createNotification(time, alarm);
                       messageTextView.setText(newText + "\n" + existingText);

                       break;
                   case "estudio3/classroomA/alert/pir":
                       emoji = "🚶"; // Pedestrian emoji for presence detection
                       alarm =  emoji + " " + emoji + " " + getString(R.string.pir) + emoji + " " + emoji;
                       newText = alarm + " " + getString(R.string.at) +" "+ time;
                       createNotification(time, alarm);
                       messageTextView.setText(newText + "\n" + existingText);

                       break;
                   case "estudio3/classroomA/alert/flame":
                       emoji = "🔥"; // Fire emoji for fire detection
                       alarm =  emoji + " " + emoji + " " + getString(R.string.flame) + emoji + " " + emoji;
                       // Set the new text on the TextView
                       newText = alarm + " " + getString(R.string.at) +" "+ time;
                       createNotification(time, alarm);
                       messageTextView.setText(newText + "\n" + existingText);

                       break;
               }

           }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });}


    private void createNotification(String time, String alert) {

        int notificationId = (int) System.currentTimeMillis();

        createNotificationChannel();

        String contentText;
        contentText = alert +" "+ getString(R.string.at)+" " + time;

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.warning)
                .setColor(Color.RED)
                .setContentTitle(getString(R.string.WARNING))
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification Channel";
            String description = "Channel for activity reminders";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    public void onDeleteButtonClick(View view) {
        messageTextView.setText("");
    }


}
