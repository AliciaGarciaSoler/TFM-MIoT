package com.example.teachersapp;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private ImageButton buttonSpanish;
    private ImageButton buttonEnglish;
    private MqttAndroidClient mqttClient;
    private static final String CHANNEL_ID = "notification_channel1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set custom layout and action bar
        setContentView(R.layout.activity_main);
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom, null);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);

        // Get MQTT client which is already subscribe to the alert topic
        mqttClient = MQTTClientManager.getMqttClient(getApplicationContext());

        buttonSpanish = findViewById(R.id.button_es);
        buttonEnglish = findViewById(R.id.button_uk);
        // Set click listeners for the buttons
        buttonSpanish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLanguage("es");
                recreate(); // Refresh the activity to apply the language change
            }
        });

        buttonEnglish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setAppLanguage("en");
                recreate(); // Refresh the activity to apply the language change
            }
        });
        // Change to the corresponding activity of the buttons
        Button showMessagesButton = findViewById(R.id.button_show_messages);
        showMessagesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MessageDisplayActivity.class);
                startActivity(intent);
            }
        });

        Button updateTimetableButton = findViewById(R.id.button_update_tt);
        updateTimetableButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, UpdateTimetableActivity.class);
                startActivity(intent);
            }
        });
        ImageButton settingsButton = findViewById(R.id.button_settings);
        settingsButton.setBackgroundTintList(null);
        settingsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent settingsIntent = new Intent(MainActivity.this, AppSettingsActivity.class);
                settingsLauncher.launch(settingsIntent);
            }
        });
        Button telemetryButton = findViewById(R.id.button_telemetry);
        telemetryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, TelemetryActivity.class);
                startActivity(intent);
            }
        });
        Button TBDButton = findViewById(R.id.button_TBD);
        TBDButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NotificationsActivity.class);
                startActivity(intent);
            }
        });

        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml(getString(R.string.infoMain)));

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        mqttClient.setCallback(new MqttCallback() {
            @Override
            public void connectionLost(Throwable cause) {

            }

            @Override
            public void messageArrived(String topic, MqttMessage message)
            {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                // Get the current time
                String time = sdf.format(new Date());
                String alarm;
                String emoji = "";
                switch (topic){
                    case "estudio3/classroomA/alert/noise":
                        emoji = "🔊"; // Speaker emoji for noise detection

                        alarm =  emoji + " " + emoji + " " + getString(R.string.noise) + emoji + " " + emoji;
                        // Create the notification
                        createNotification(time, alarm);

                        break;
                    case "estudio3/classroomA/alert/touch":
                        emoji = "👆"; // Finger pointing emoji for touch detection
                        alarm =  emoji + " " + emoji + " " + getString(R.string.touch) + emoji + " " + emoji;
                        createNotification(time, alarm);

                        break;
                    case "estudio3/classroomA/alert/pir":
                        emoji = "🚶"; // Pedestrian emoji for presence detection
                        alarm =  emoji + " " + emoji + " " + getString(R.string.pir) + emoji + " " + emoji;
                        createNotification(time, alarm);

                        break;
                    case "estudio3/classroomA/alert/flame":
                        emoji = "🔥"; // Fire emoji for fire detection
                        alarm =  emoji + " " + emoji + " " + getString(R.string.flame) + emoji + " " + emoji;
                        createNotification(time, alarm);

                        break;
                    default:
                        alarm =  "alarm";
                        time = "now";
                        createNotification(time, alarm);
                        break;
                }
                }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {

            }
        });

    }
    private ActivityResultLauncher<Intent> settingsLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == RESULT_OK) {
                    // Restart the MQTT manager
                    restartMqttManager();
                }
            }
    );
    private void restartMqttManager() {
        Toast.makeText(MainActivity.this, "Restarted", Toast.LENGTH_SHORT).show();
        MQTTClientManager.setRestartingFlag(true);

        // Disconnect and close the existing MQTT client
        if (mqttClient != null) {
            try {
                mqttClient.disconnect();
                mqttClient = null;
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }

        // Finish the current activity and start a new instance of MainActivity
        finish();
        startActivity(new Intent(MainActivity.this, MainActivity.class));
    }

    private void setAppLanguage(String language) {
        Locale locale = new Locale(language);
        Locale.setDefault(locale);

        Resources resources = getResources();
        Configuration configuration = resources.getConfiguration();
        configuration.setLocale(locale);

        resources.updateConfiguration(configuration, resources.getDisplayMetrics());
    }

    private void createNotification(String time, String alert) {

        // Create a unique notification ID based on current time
        int notificationId = (int) System.currentTimeMillis();
        createNotificationChannel();

        String contentText;
        contentText = alert +" "+ getString(R.string.at)+" " + time;
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.mipmap.warning)
                .setColor(Color.RED)
                .setContentTitle(getString(R.string.WARNING))
                .setContentText(contentText)
                .setPriority(NotificationCompat.PRIORITY_HIGH);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        notificationManager.notify(notificationId, builder.build());
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Notification Channel";
            String description = "Channel for alerts";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

}
