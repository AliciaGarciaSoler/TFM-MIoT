package com.example.teachersapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.Html;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.DisconnectedBufferOptions;
import org.eclipse.paho.client.mqttv3.IMqttActionListener;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.IMqttToken;
import org.eclipse.paho.client.mqttv3.MqttCallbackExtended;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;



import java.util.ArrayList;
import java.util.List;

public class UpdateTimetableActivity extends AppCompatActivity{


    private ImageButton selectedButton;
    private MqttAndroidClient mqttClient;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.update_timetable);

        LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View actionBar = inflater.inflate(R.layout.action_bar_custom_timetable, null);
        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(
                ActionBar.LayoutParams.MATCH_PARENT,
                ActionBar.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER_VERTICAL
        );
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.primaryColor)));
        getSupportActionBar().setCustomView(actionBar, layoutParams);

        mqttClient = MQTTClientManager.getMqttClient(getApplicationContext());

        ImageButton SpanishButton = findViewById(R.id.buttonSpanish);
        ImageButton MathButton = findViewById(R.id.buttonMath);
        ImageButton ScienceButton = findViewById(R.id.buttonScience);
        ImageButton PaintButton = findViewById(R.id.buttonPaint);
        ImageButton BreakButton = findViewById(R.id.buttonBreak);
        ImageButton EnglishButton = findViewById(R.id.buttonEnglish);
        SpanishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });

        MathButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });

        ScienceButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });

        PaintButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });

        BreakButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });

        EnglishButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                handleImageButtonClick(v);
            }
        });
        ImageButton infoButton = actionBar.findViewById(R.id.button_info);
        infoButton.setBackgroundTintList(null);
        infoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create pop up window
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateTimetableActivity.this);
                builder.setTitle("Info");
                builder.setMessage(Html.fromHtml(getString(R.string.timetableAlert) ));

                // Add a button
                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int whichButton) {
                        dialog.dismiss();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
    private void handleImageButtonClick(View view) {
        // Deselect the previously selected button (if any)
        if (selectedButton != null) {
            selectedButton.setSelected(false);

        }

        ImageButton button = (ImageButton) view;
        button.setSelected(true);
        selectedButton = button;

    }

    public void onSendButtonClicked(View view) {
        if (selectedButton == null) {
            Toast.makeText(this, "Please select an image first", Toast.LENGTH_SHORT).show();
            return;
        }


        String payload = "";
        String mqttTopic = "estudio3/classroomA/updates/timetable";

        // Set the payload based on the selected image button
        switch (selectedButton.getId()) {
            case R.id.buttonMath:
                payload = "Math";
                break;
            case R.id.buttonScience:
                payload = "Science";
                break;
            case R.id.buttonEnglish:
                payload = "English";
                break;
            case R.id.buttonSpanish:
                payload = "Spanish";
                break;
            case R.id.buttonPaint:
                payload = "Paint";
                break;
            case R.id.buttonBreak:
                payload = "Break";
                break;
        }

        try {
            MqttMessage message = new MqttMessage(payload.getBytes());
            message.setQos(1);
            mqttClient.publish(mqttTopic, message);
            Toast.makeText(UpdateTimetableActivity.this, "Published: " + payload, Toast.LENGTH_SHORT).show();
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

}


